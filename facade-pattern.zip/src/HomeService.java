public interface HomeService {
    void turnOn();
    void turnOff();
}
